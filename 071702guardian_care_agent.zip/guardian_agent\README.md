# Guardian Care Agent

独居老人边缘照护智能体原型。项目当前用于本地模拟、网页演示、涂鸦智能体 MCP 接入测试，以及后续接入真实服务器、树莓派和双端 App。

## 当前能力

- 起夜场景：识别离床、去卫生间、喝水、返床、头晕、摔倒、需要帮助、长时间无响应等情况。
- 健康日报和周报：基于模拟体征数据生成老人维度的日报、周报和近期数据摘要。
- 家庭回忆库：保留 30 段模拟通话音频和对应记忆处理能力，用于后续接入真实录音。
- 前端看板：展示风险卡片、Agent 决策时间线、事件详情、健康日报/周报、最近日常数据、家庭回忆。
- MCP 服务：面向涂鸦平台提供 3 个工具，控制工具数量不超过涂鸦限制。

## 目录结构

```text
guardian_agent/
  agent/                    核心智能体逻辑
  evals/                    起夜语义评测集
  integrations/             语音模型桥接脚本和说明
  samples/audio/            30 段家庭回忆模拟音频
  simulator/                本地模拟器
  static/                   前端网页
  tests/                    自动化测试
  guardian_tools.py         MCP 工具后端
  mcp_server.py             MCP 服务入口
  server.py                 本地网页和 API 服务
  guardian_agent.sqlite3    SQLite 模拟数据
  requirements.txt          Python 依赖
  README.md                 本说明
```

## 本地运行

进入项目目录：

```powershell
cd guardian_agent
```

安装依赖：

```powershell
python -m pip install -r .\requirements.txt
```

启动网页和本地 API：

```powershell
python .\server.py
```

浏览器打开：

```text
http://127.0.0.1:8765
```

启动 MCP 服务：

```powershell
$env:GUARDIAN_MCP_API_KEY="guardian-demo-20260716"
python .\mcp_server.py
```

成功后会看到：

```text
Uvicorn running on http://127.0.0.1:8000
```

## 暴露给涂鸦平台

另开一个 PowerShell：

```powershell
cloudflared tunnel --protocol http2 --url http://127.0.0.1:8000
```

复制生成的公网地址，在涂鸦平台 MCP 服务中填写：

```text
https://你的地址.trycloudflare.com/mcp?key=guardian-demo-20260716
```

注意：quick tunnel 每次重开都会生成新地址，需要同步更新涂鸦平台配置。三个窗口都要保持打开：网页服务、MCP 服务、cloudflared 隧道。

## 涂鸦智能体 Prompt 建议

```text
你是 Guardian Care 独居老人居家照护智能体。用户会用自然语言描述老人照护场景。你需要根据老人姓名、事件内容和上下文，主动完成记录、分析、提醒、报告查询或事件升级。不要要求用户提供工具名、参数名、老人编号或技术字段。回复时保持照护助手口吻，不要提到网页、接口、数据库、MCP、action、参数、工具调用等技术词。

当用户询问老人名单、老人列表、当前服务对象时，调用 list_elders。
当用户描述起夜、摔倒、无响应、返床、喝水、去卫生间、头晕或需要帮助时，调用 night_care_workflow。
当用户询问今日健康、身体数据、日报、周报、一周情况时，调用 health_report_workflow。
如果用户使用老人姓名，可以直接用姓名处理，不要要求用户提供老人编号。
```

## 自然语言测试话术

这些话术用于涂鸦在线调试，不需要提到工具名或技术参数：

```text
现在有哪些老人正在由你照护？
我想看看王爷爷这一周的健康情况。
张爷爷今天的身体数据怎么样？
王爷爷刚才起夜了，他说去趟卫生间，不用担心。
张爷爷半夜离床了，他说只是起来喝口水。
王爷爷已经回到床上了。
王爷爷说他摔倒了，起不来。
张爷爷起夜后说有点头晕，站不稳。
王爷爷离床后一直没有回应。
李奶奶起夜后很久没有声音，也没有回答。
```

## MCP 工具

当前只暴露 3 个工具，适配涂鸦平台最多 10 个工具的限制：

- `list_elders`：查询当前服务老人。
- `night_care_workflow`：统一处理起夜、老人反馈、返床、无响应、摔倒和事件关闭。
- `health_report_workflow`：统一处理健康日报、健康周报和近期体征数据。

## 测试

```powershell
python -m unittest tests.test_guardian_tools tests.test_conversation tests.test_guardian_message -v
```

当前打包前通过 28 个测试。

## 备注

- `guardian_agent.sqlite3` 是本地模拟数据，可用于演示；如需重置，可删除后重新启动服务，系统会自动生成模拟数据。
- `mcp_call_debug.log` 是本地调试日志，不应提交到 GitHub。
- `__pycache__`、历史压缩包和临时输出不需要提交。

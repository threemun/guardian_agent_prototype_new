from __future__ import annotations

import contextlib
import json
import hmac
import os
from collections.abc import Awaitable, Callable
from datetime import datetime
from urllib.parse import parse_qs

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from starlette.applications import Starlette
from starlette.routing import Mount
import uvicorn

import guardian_tools


HOST = os.getenv("GUARDIAN_MCP_HOST", "127.0.0.1")
PORT = int(os.getenv("GUARDIAN_MCP_PORT", "8000"))
API_KEY = os.getenv("GUARDIAN_MCP_API_KEY", "").strip()


mcp = FastMCP(
    "Guardian Care MCP",
    instructions=(
        "Use these tools to query Guardian elder-care events, submit normalized "
        "elder feedback, record Tuya device actions, and read or generate health "
        "daily/weekly reports. Never invent an event_id. Health reports are only "
        "for daily care reference and must not be treated as a medical diagnosis. "
        "Natural Chinese requests should be handled by calling the matching tool, "
        "not by asking the user to provide action names or technical parameters."
    ),
    host=HOST,
    port=PORT,
    stateless_http=True,
    json_response=True,
    # The service listens locally by default. When exposed through a tunnel, the
    # public Host is dynamic, so DNS rebinding protection is disabled here.
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
)


class ApiKeyAuthMiddleware:
    """Accept a Bearer header or Tuya-compatible ``?key=`` authentication."""

    def __init__(self, app: Callable[..., Awaitable[None]], api_key: str) -> None:
        self.app = app
        self.api_key = api_key

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope.get("type") != "http" or not self.api_key:
            await self.app(scope, receive, send)
            return

        headers = {key.lower(): value for key, value in scope.get("headers", [])}
        supplied = headers.get(b"authorization", b"").decode("utf-8", errors="ignore")
        expected = f"Bearer {self.api_key}"
        query_string = scope.get("query_string", b"").decode("utf-8", errors="ignore")
        query_keys = parse_qs(query_string, keep_blank_values=True).get("key", [])
        query_key_matches = any(
            hmac.compare_digest(candidate, self.api_key) for candidate in query_keys
        )
        if hmac.compare_digest(supplied, expected) or query_key_matches:
            await self.app(scope, receive, send)
            return

        body = b'{"error":"unauthorized"}'
        await send(
            {
                "type": "http.response.start",
                "status": 401,
                "headers": [
                    (b"content-type", b"application/json; charset=utf-8"),
                    (b"content-length", str(len(body)).encode("ascii")),
                    (b"www-authenticate", b"Bearer"),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


@mcp.tool()
def list_elders() -> dict:
    """List elders available to the Guardian demo and their elder IDs."""
    return guardian_tools.list_elders()


@mcp.tool()
def night_care_workflow(
    action: str = "",
    elder_id: str = "E001",
    elder_name: str = "",
    event_id: str = "",
    feedback_type: str = "",
    original_text: str = "",
    text: str = "",
    transcript: str = "",
    original: str = "",
    source: str = "tuya_agent",
    device_action: str = "",
    device_success: bool = True,
    device_detail: str = "",
) -> dict:
    """
    Run the night-care workflow through one tool.

    action options:
    list_elders, get_active_event, get_event_detail, get_event_timeline,
    submit_feedback, handle_elder_reply, night_turn, request_emergency_help,
    confirm_return_to_bed, no_response_timeout, record_device_action,
    close_event. Use original_text, text, transcript, or original for the
    elder's raw reply. For fall, unable to get up, or urgent help, use
    request_emergency_help. Aliases such as escalate_event, upgrade_event,
    fall_detected, elder_reply, timeout, and return_to_bed are accepted.
    If action is omitted, the workflow infers it from original_text and other
    fields. Natural Chinese is enough: for example "王爷爷离床后长时间没有回应"
    is treated as no_response_timeout. elder_name can be used instead of elder_id.
    """
    args = {
        "action": action,
        "elder_id": elder_id,
        "elder_name": elder_name,
        "event_id": event_id,
        "feedback_type": feedback_type,
        "original_text": original_text,
        "text": text,
        "transcript": transcript,
        "original": original,
        "source": source,
        "device_action": device_action,
        "device_success": device_success,
        "device_detail": device_detail,
    }
    try:
        result = guardian_tools.night_care_workflow(**args)
    except Exception as exc:
        _append_tool_debug_log("night_care_workflow", args, error=str(exc))
        raise
    _append_tool_debug_log("night_care_workflow", args, result=result)
    return result


@mcp.tool()
def health_report_workflow(
    action: str = "weekly_report",
    elder_id: str = "E001",
    report_date: str = "",
    week_end: str = "",
    limit: int = 7,
) -> dict:
    """
    Run daily/weekly health report workflow through one tool.

    action options:
    daily_report, weekly_report, get_daily_report, generate_daily_report,
    get_weekly_report, generate_weekly_report, get_recent_vitals,
    refresh_all_reports. Advisory only, not medical diagnosis.
    """
    return guardian_tools.health_report_workflow(
        action=action,
        elder_id=elder_id,
        report_date=report_date,
        week_end=week_end,
        limit=limit,
    )


@contextlib.asynccontextmanager
async def lifespan(app: Starlette):
    """Start and stop the MCP Streamable HTTP session manager cleanly."""
    async with mcp.session_manager.run():
        yield


app = ApiKeyAuthMiddleware(
    Starlette(
        routes=[Mount("/", app=mcp.streamable_http_app())],
        lifespan=lifespan,
    ),
    API_KEY,
)


def _append_tool_debug_log(
    tool_name: str,
    args: dict,
    result: dict | None = None,
    error: str = "",
) -> None:
    event = result.get("event", {}) if isinstance(result, dict) else {}
    if not isinstance(event, dict):
        event = {}
    result_summary = {}
    if isinstance(result, dict):
        result_summary = {
            "workflow": result.get("workflow"),
            "action": result.get("action"),
            "accepted": result.get("accepted"),
            "intent": result.get("intent"),
            "event_id": result.get("event_id") or event.get("id"),
            "event_status": result.get("event_status") or event.get("status"),
            "risk_level": result.get("risk_level") or event.get("risk_level"),
        }
    line = {
        "at": datetime.now().isoformat(timespec="seconds"),
        "tool": tool_name,
        "args": args,
        "result": result_summary,
        "error": error,
    }
    with open("mcp_call_debug.log", "a", encoding="utf-8") as file:
        file.write(json.dumps(line, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    guardian_tools.ensure_demo_database()
    if not API_KEY:
        print("警告：未设置 GUARDIAN_MCP_API_KEY，仅适合本机测试。")
    # Tuya only permits URL-based authentication in some Streamable HTTP configs.
    # Keep query-string credentials out of the service journal.
    uvicorn.run(app, host=HOST, port=PORT, access_log=False)

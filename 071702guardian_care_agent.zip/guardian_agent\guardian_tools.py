from __future__ import annotations

from typing import Any

from agent.conversation import handle_night_turn
from agent.db import get_conn, init_db, row_to_dict
from agent.health import HealthAgent
from agent.night import NightCareAgent
from agent.seed import seed_demo_data


VALID_FEEDBACK_TYPES = {"ok", "bathroom", "drink", "dizzy", "need_help", "unknown"}
VALID_NIGHT_WORKFLOW_ACTIONS = {
    "list_elders",
    "get_active_event",
    "get_event_detail",
    "get_event_timeline",
    "submit_feedback",
    "handle_elder_reply",
    "night_turn",
    "request_emergency_help",
    "confirm_return_to_bed",
    "no_response_timeout",
    "record_device_action",
    "close_event",
}
VALID_HEALTH_WORKFLOW_ACTIONS = {
    "daily_report",
    "weekly_report",
    "get_daily_report",
    "generate_daily_report",
    "get_weekly_report",
    "generate_weekly_report",
    "get_recent_vitals",
    "refresh_all_reports",
}
NO_RESPONSE_MARKERS = [
    "没有回应",
    "没回应",
    "无回应",
    "未回应",
    "没有回答",
    "没回答",
    "无人回答",
    "没有应答",
    "没应答",
    "无应答",
    "未应答",
    "没有响应",
    "没响应",
    "无响应",
    "未响应",
    "没有回话",
    "没回话",
    "没有声音",
    "没声音",
    "无人声",
    "一直没有",
    "一直没",
    "长时间没有",
    "长时间没",
    "超时",
    "timeout",
    "no response",
    "not responding",
    "no answer",
]
ACTION_ALIASES = {
    "elder_reply": "night_turn",
    "submit_elder_reply": "night_turn",
    "handle_reply": "night_turn",
    "reply": "night_turn",
    "night-turn": "night_turn",
    "night turn": "night_turn",
    "escalate": "request_emergency_help",
    "escalate_event": "request_emergency_help",
    "upgrade_event": "request_emergency_help",
    "request_help": "request_emergency_help",
    "emergency": "request_emergency_help",
    "fall": "request_emergency_help",
    "fall_detected": "request_emergency_help",
    "fallen": "request_emergency_help",
    "timeout": "no_response_timeout",
    "no_response": "no_response_timeout",
    "no_response_timeout": "no_response_timeout",
    "return_to_bed": "confirm_return_to_bed",
    "back_to_bed": "confirm_return_to_bed",
    "confirm_return": "confirm_return_to_bed",
    "升级事件": "request_emergency_help",
    "紧急升级": "request_emergency_help",
    "立即升级": "request_emergency_help",
    "摔倒": "request_emergency_help",
    "跌倒": "request_emergency_help",
    "需要帮助": "request_emergency_help",
    "求助": "request_emergency_help",
    "紧急帮助": "request_emergency_help",
    "老人回复": "night_turn",
    "提交老人回复": "night_turn",
    "起夜反馈": "night_turn",
    "无响应": "no_response_timeout",
    "未响应": "no_response_timeout",
    "超时": "no_response_timeout",
    "返床": "confirm_return_to_bed",
    "已返床": "confirm_return_to_bed",
    "确认返床": "confirm_return_to_bed",
}
HEALTH_REPORT_NOTE = "本报告仅用于日常健康管理参考，不能替代医生诊断；如老人出现明显不适，请及时联系医护人员。"


def ensure_demo_database() -> None:
    """Create the database and seed demo data when the project is first run."""
    init_db(reset=False)
    with get_conn() as conn:
        elder_count = conn.execute("SELECT COUNT(*) FROM elders").fetchone()[0]
    if elder_count == 0:
        seed_demo_data(reset=True)


def list_elders() -> dict[str, Any]:
    """List demo elders so tool testing does not need hard-coded guesses."""
    ensure_demo_database()
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, name, room, care_level, device_host FROM elders ORDER BY id"
        ).fetchall()
        return {"items": [row_to_dict(row) for row in rows]}


def get_active_event(elder_id: str = "E001") -> dict[str, Any]:
    """Return the newest non-closed care event for an elder."""
    _require_text(elder_id, "elder_id")
    ensure_demo_database()
    with get_conn() as conn:
        row = conn.execute(
            """
            SELECT * FROM events
            WHERE elder_id = ? AND status != 'CLOSED'
            ORDER BY created_at DESC, rowid DESC
            LIMIT 1
            """,
            (elder_id,),
        ).fetchone()
        if not row:
            return {
                "found": False,
                "elder_id": elder_id,
                "message": "当前没有待处理的照护事件。",
            }
        event = NightCareAgent(conn).get_event(row["id"])
        return {"found": True, "event": event}


def get_event_detail(event_id: str) -> dict[str, Any]:
    """Return one event including elder information and its full timeline."""
    _require_text(event_id, "event_id")
    ensure_demo_database()
    with get_conn() as conn:
        event = NightCareAgent(conn).get_event(event_id)
        if not event:
            raise ValueError(f"event not found: {event_id}")
        return event


def get_event_timeline(event_id: str) -> dict[str, Any]:
    """Return the auditable observation, decision, tool and feedback steps."""
    event = get_event_detail(event_id)
    return {
        "event_id": event_id,
        "status": event["status"],
        "risk_level": event["risk_level"],
        "items": event["timeline"],
    }


def submit_elder_feedback(
    event_id: str,
    feedback_type: str,
    original_text: str = "",
    source: str = "tuya_agent",
    elder_id: str = "",
) -> dict[str, Any]:
    """Apply a normalized elder response to an existing Guardian event."""
    _require_text(event_id, "event_id")
    if feedback_type not in VALID_FEEDBACK_TYPES:
        allowed = ", ".join(sorted(VALID_FEEDBACK_TYPES))
        raise ValueError(f"invalid feedback_type; expected one of: {allowed}")

    ensure_demo_database()
    with get_conn() as conn:
        agent = NightCareAgent(conn)
        event = agent.get_event(event_id)
        if not event:
            raise ValueError(f"event not found: {event_id}")
        if elder_id and event["elder_id"] != elder_id:
            raise ValueError("event_id does not belong to elder_id")
        if event["status"] == "CLOSED":
            raise ValueError("event is already closed")
        updated = agent.apply_feedback(
            event_id,
            feedback_type,
            original_text=original_text.strip(),
            source=source.strip() or "tuya_agent",
        )
        return {
            "accepted": True,
            "event": updated,
            "message": "老人反馈已写入 Guardian 事件时间线。",
        }


def request_emergency_help(
    event_id: str,
    original_text: str = "老人请求帮助",
    elder_id: str = "",
) -> dict[str, Any]:
    """Escalate an active event when the elder explicitly asks for help."""
    return submit_elder_feedback(
        event_id=event_id,
        elder_id=elder_id,
        feedback_type="need_help",
        original_text=original_text,
        source="tuya_agent",
    )


def record_device_action(
    event_id: str,
    action: str,
    success: bool,
    detail: str = "",
    source: str = "tuya_agent",
) -> dict[str, Any]:
    """Record the result of a Tuya light or scene action in the timeline."""
    _require_text(event_id, "event_id")
    _require_text(action, "action")
    ensure_demo_database()
    with get_conn() as conn:
        updated = NightCareAgent(conn).record_device_action(
            event_id=event_id,
            action=action.strip(),
            success=success,
            detail=detail.strip(),
            source=source.strip() or "tuya_agent",
        )
        return {
            "recorded": True,
            "event": updated,
            "message": "设备动作结果已写入 Guardian 事件时间线。",
        }


def close_event(event_id: str) -> dict[str, Any]:
    """Close an event after a human or trusted workflow confirms resolution."""
    _require_text(event_id, "event_id")
    ensure_demo_database()
    with get_conn() as conn:
        agent = NightCareAgent(conn)
        event = agent.get_event(event_id)
        if not event:
            raise ValueError(f"event not found: {event_id}")
        if event["status"] == "CLOSED":
            return {"closed": True, "event": event, "message": "事件此前已经关闭。"}
        updated = agent.close_event(event_id)
        return {"closed": True, "event": updated, "message": "事件已关闭并归档。"}


def night_care_workflow(
    action: str = "",
    elder_id: str = "E001",
    elder_name: str = "",
    event_id: str = "",
    feedback_type: str = "",
    original_text: str = "",
    text: str = "",
    transcript: str = "",
    original: str = "",
    source: str = "tuya_agent",
    device_action: str = "",
    device_success: bool = True,
    device_detail: str = "",
) -> dict[str, Any]:
    """
    One Tuya-facing workflow tool for night-care events.

    Supported actions: list_elders, get_active_event, get_event_detail,
    get_event_timeline, submit_feedback, handle_elder_reply, night_turn,
    request_emergency_help, confirm_return_to_bed, no_response_timeout,
    record_device_action, close_event.
    """
    elder_text = (original_text or text or transcript or original or "").strip()
    resolved_elder_id = _resolve_elder_id(elder_id, elder_name)
    requested_action = (action or "").strip()
    if not requested_action:
        if feedback_type.strip():
            requested_action = "handle_elder_reply"
        elif device_action.strip():
            requested_action = "record_device_action"
        elif _looks_like_no_response(elder_text, device_action, device_detail):
            requested_action = "no_response_timeout"
        elif elder_text:
            requested_action = "night_turn"
        else:
            requested_action = "get_active_event"
    normalized_action = _normalize_action(requested_action, VALID_NIGHT_WORKFLOW_ACTIONS, "night workflow action")
    if normalized_action in {"night_turn", "submit_feedback", "handle_elder_reply"} and _looks_like_no_response(
        elder_text,
        device_action,
        device_detail,
    ):
        normalized_action = "no_response_timeout"
    if normalized_action in {"submit_feedback", "handle_elder_reply"} and not feedback_type.strip() and elder_text:
        normalized_action = "night_turn"

    if normalized_action == "list_elders":
        return {"workflow": "night_care", "action": normalized_action, **list_elders()}
    if normalized_action == "get_active_event":
        return {"workflow": "night_care", "action": normalized_action, **get_active_event(resolved_elder_id)}
    if normalized_action == "get_event_detail":
        _require_text(event_id, "event_id")
        return {"workflow": "night_care", "action": normalized_action, "event": get_event_detail(event_id)}
    if normalized_action == "get_event_timeline":
        _require_text(event_id, "event_id")
        return {"workflow": "night_care", "action": normalized_action, **get_event_timeline(event_id)}
    if normalized_action == "submit_feedback":
        _require_text(feedback_type, "feedback_type")
        target_event_id = event_id.strip() or _active_event_id_or_create(resolved_elder_id)
        return {
            "workflow": "night_care",
            "action": normalized_action,
            **submit_elder_feedback(
                event_id=target_event_id,
                elder_id=resolved_elder_id,
                feedback_type=feedback_type,
                original_text=elder_text,
                source=source,
            ),
        }
    if normalized_action == "handle_elder_reply":
        _require_text(feedback_type, "feedback_type")
        target_event_id = event_id.strip() or _active_event_id(resolved_elder_id)
        return {
            "workflow": "night_care",
            "action": normalized_action,
            **submit_elder_feedback(
                event_id=target_event_id,
                elder_id=resolved_elder_id,
                feedback_type=feedback_type,
                original_text=elder_text,
                source=source,
            ),
        }
    if normalized_action == "night_turn":
        _require_text(elder_text, "original_text")
        target_event_id = event_id.strip() or _active_event_id_or_create(resolved_elder_id)
        with get_conn() as conn:
            return {
                "workflow": "night_care",
                "action": normalized_action,
                **handle_night_turn(
                    conn,
                    {
                        "elder_id": resolved_elder_id,
                        "event_id": target_event_id,
                        "text": elder_text,
                        "source": source,
                    },
                ),
            }
    if normalized_action == "request_emergency_help":
        target_event_id = event_id.strip() or _active_event_id_or_create(resolved_elder_id, scenario="critical")
        return {
            "workflow": "night_care",
            "action": normalized_action,
            **request_emergency_help(
                event_id=target_event_id,
                elder_id=resolved_elder_id,
                original_text=elder_text or "老人请求帮助",
            ),
        }
    if normalized_action == "confirm_return_to_bed":
        target_event_id = event_id.strip() or _active_event_id(resolved_elder_id)
        with get_conn() as conn:
            event = NightCareAgent(conn).confirm_return_to_bed(
                target_event_id,
                source=source,
                detail=elder_text or "涂鸦或设备确认老人已返床。",
            )
            return {
                "workflow": "night_care",
                "action": normalized_action,
                "event": event,
                "message": "返床确认已写入 Guardian 事件时间线。",
            }
    if normalized_action == "no_response_timeout":
        target_event_id = event_id.strip() or _active_event_id_or_create(resolved_elder_id, scenario="critical")
        with get_conn() as conn:
            event = NightCareAgent(conn).simulate_timeout(target_event_id)
            return {
                "workflow": "night_care",
                "action": normalized_action,
                "event": event,
                "message": "无响应超时已写入 Guardian 事件时间线。",
            }
    if normalized_action == "record_device_action":
        _require_text(event_id, "event_id")
        _require_text(device_action, "device_action")
        return {
            "workflow": "night_care",
            "action": normalized_action,
            **record_device_action(
                event_id=event_id,
                action=device_action,
                success=_normalize_bool(device_success),
                detail=device_detail,
                source=source,
            ),
        }
    if normalized_action == "close_event":
        target_event_id = event_id.strip() or _active_event_id(resolved_elder_id)
        return {"workflow": "night_care", "action": normalized_action, **close_event(target_event_id)}

    raise ValueError(f"unsupported night workflow action: {action}")


def get_daily_report(elder_id: str = "E001") -> dict[str, Any]:
    """Return the latest stored daily health report for an elder."""
    _require_text(elder_id, "elder_id")
    ensure_demo_database()
    with get_conn() as conn:
        report = HealthAgent(conn).latest_report(elder_id, "daily")
        if not report:
            return {
                "found": False,
                "elder_id": elder_id,
                "report_note": HEALTH_REPORT_NOTE,
                "message": "当前没有已生成的健康日报。",
            }
        return _report_payload(report)


def generate_daily_report(elder_id: str = "E001", report_date: str = "") -> dict[str, Any]:
    """Generate and store a daily health report from the elder's recent vitals."""
    _require_text(elder_id, "elder_id")
    ensure_demo_database()
    with get_conn() as conn:
        report = HealthAgent(conn).generate_daily_report(elder_id, report_date.strip() or None)
        return _report_payload(report)


def get_weekly_report(elder_id: str = "E001") -> dict[str, Any]:
    """Return the latest stored weekly health report for an elder."""
    _require_text(elder_id, "elder_id")
    ensure_demo_database()
    with get_conn() as conn:
        report = HealthAgent(conn).latest_report(elder_id, "weekly")
        if not report:
            return {
                "found": False,
                "elder_id": elder_id,
                "report_note": HEALTH_REPORT_NOTE,
                "message": "当前没有已生成的健康周报。",
            }
        return _report_payload(report)


def generate_weekly_report(elder_id: str = "E001", week_end: str = "") -> dict[str, Any]:
    """Generate and store a weekly health report from the elder's recent vitals."""
    _require_text(elder_id, "elder_id")
    ensure_demo_database()
    with get_conn() as conn:
        report = HealthAgent(conn).generate_weekly_report(elder_id, week_end.strip() or None)
        return _report_payload(report)


def get_recent_vitals(elder_id: str = "E001", limit: int = 7) -> dict[str, Any]:
    """Return recent vitals used by the daily and weekly health report tools."""
    _require_text(elder_id, "elder_id")
    ensure_demo_database()
    with get_conn() as conn:
        items = HealthAgent(conn).latest_vitals(elder_id, _normalize_limit(limit))
        return {
            "elder_id": elder_id,
            "items": items,
            "count": len(items),
            "report_note": HEALTH_REPORT_NOTE,
        }


def health_report_workflow(
    action: str = "weekly_report",
    elder_id: str = "E001",
    report_date: str = "",
    week_end: str = "",
    limit: int = 7,
) -> dict[str, Any]:
    """
    One Tuya-facing workflow tool for daily/weekly health reports.

    Supported actions: daily_report, weekly_report, get_daily_report,
    generate_daily_report, get_weekly_report, generate_weekly_report,
    get_recent_vitals, refresh_all_reports.
    """
    normalized_action = _normalize_action(action, VALID_HEALTH_WORKFLOW_ACTIONS, "health workflow action")

    if normalized_action == "daily_report":
        report = get_daily_report(elder_id)
        if not report.get("found"):
            report = generate_daily_report(elder_id, report_date)
        return {"workflow": "health_report", "action": normalized_action, **report}
    if normalized_action == "weekly_report":
        report = get_weekly_report(elder_id)
        if not report.get("found"):
            report = generate_weekly_report(elder_id, week_end)
        return {"workflow": "health_report", "action": normalized_action, **report}
    if normalized_action == "get_daily_report":
        return {"workflow": "health_report", "action": normalized_action, **get_daily_report(elder_id)}
    if normalized_action == "generate_daily_report":
        return {"workflow": "health_report", "action": normalized_action, **generate_daily_report(elder_id, report_date)}
    if normalized_action == "get_weekly_report":
        return {"workflow": "health_report", "action": normalized_action, **get_weekly_report(elder_id)}
    if normalized_action == "generate_weekly_report":
        return {"workflow": "health_report", "action": normalized_action, **generate_weekly_report(elder_id, week_end)}
    if normalized_action == "get_recent_vitals":
        return {"workflow": "health_report", "action": normalized_action, **get_recent_vitals(elder_id, limit)}
    if normalized_action == "refresh_all_reports":
        daily = generate_daily_report(elder_id, report_date)
        weekly = generate_weekly_report(elder_id, week_end)
        vitals = get_recent_vitals(elder_id, limit)
        return {
            "workflow": "health_report",
            "action": normalized_action,
            "elder_id": elder_id,
            "daily_report": daily,
            "weekly_report": weekly,
            "recent_vitals": vitals,
            "report_note": HEALTH_REPORT_NOTE,
        }

    raise ValueError(f"unsupported health workflow action: {action}")


def _report_payload(report: dict[str, Any]) -> dict[str, Any]:
    return {
        "found": True,
        "elder_id": report["elder_id"],
        "report_type": report["report_type"],
        "period_start": report["period_start"],
        "period_end": report["period_end"],
        "risk_level": report["risk_level"],
        "title": report["title"],
        "summary": report["summary"],
        "content": report.get("content", {}),
        "created_at": report["created_at"],
        "report_note": HEALTH_REPORT_NOTE,
    }


def _require_text(value: str, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} is required")


def _active_event_id(elder_id: str) -> str:
    active = get_active_event(elder_id)
    if not active.get("found"):
        raise ValueError(f"no active event found for elder_id: {elder_id}")
    return active["event"]["id"]


def _active_event_id_or_create(elder_id: str, scenario: str = "standard") -> str:
    active = get_active_event(elder_id)
    if active.get("found"):
        return active["event"]["id"]

    ensure_demo_database()
    critical = scenario == "critical"
    signals = {
        "sleep_band_no_body_seconds": 720 if critical else 320,
        "radar_movement": not critical,
        "night_time": True,
        "mcp_created": True,
    }
    with get_conn() as conn:
        event = NightCareAgent(conn).trigger_possible_leave_bed(
            elder_id=elder_id,
            scenario="critical" if critical else "standard",
            signals=signals,
            location="卧室",
        )
        return event["id"]


def _resolve_elder_id(elder_id: str = "", elder_name: str = "") -> str:
    candidate = (elder_id or "").strip()
    if candidate.startswith("E"):
        return candidate

    name = (elder_name or candidate).strip()
    if name:
        ensure_demo_database()
        with get_conn() as conn:
            row = conn.execute(
                """
                SELECT id FROM elders
                WHERE name = ? OR name LIKE ?
                ORDER BY id
                LIMIT 1
                """,
                (name, f"%{name}%"),
            ).fetchone()
            if row:
                return row["id"]
    return candidate or "E001"


def _normalize_action(action: str, allowed: set[str], field_name: str) -> str:
    _require_text(action, field_name)
    normalized = action.strip()
    normalized_key = normalized.lower().replace("-", "_").replace(" ", "_")
    normalized = ACTION_ALIASES.get(normalized, ACTION_ALIASES.get(normalized_key, normalized_key))
    if normalized not in allowed:
        allowed_text = ", ".join(sorted(allowed))
        raise ValueError(f"invalid {field_name}; expected one of: {allowed_text}")
    return normalized


def _looks_like_no_response(*texts: str) -> bool:
    combined = " ".join(str(text or "") for text in texts).strip().lower()
    normalized = combined.replace(" ", "")
    return any(marker.lower().replace(" ", "") in normalized for marker in NO_RESPONSE_MARKERS)


def _normalize_bool(value: bool | str | int) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "ok", "success", "succeeded"}
    return bool(value)


def _normalize_limit(limit: int) -> int:
    try:
        parsed = int(limit)
    except (TypeError, ValueError):
        parsed = 7
    return max(1, min(parsed, 30))
